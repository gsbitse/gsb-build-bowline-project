/**
 * @file
 * README file for Workbench Access.
 */

Workbench Access
A pluggable, hierarchical editorial access control system

Please see https://drupal.org/documentation/modules/workbench_access for
documentation, including installation and configuration walkthroughs.

----------------
Version history
----------------

7.2-1.2 27-JAN-2013
7.x-1.1 18-JAN-2013
7.x-1.0 26-AUG-2011
