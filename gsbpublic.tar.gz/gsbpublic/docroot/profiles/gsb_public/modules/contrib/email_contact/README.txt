EMAIL CONTACT
---------------------

Homepage: http://drupal.org/project/email_contact

Contents of this file:

 * Introduction
 * Installation

INTRODUCTION
------------

This module provides display formatters for the
email field to display email as a link to the
contact form, or as an inline contact form.

Depends on the Email module.

The contact form functionality was separated out
from the Email module.

For the inline contact form the basic idea comes
from this issue: #1264210
Initial development by jdelaune,
autmuseums.info

Sponsored by:
Inovae