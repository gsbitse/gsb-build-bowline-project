Drupal.wysiwyg.editor.markitup.sets.default = {
  bold: {name:'Bold', key:'B', openWith:'(!(<strong>|!|<b>)!)', closeWith:'(!(</strong>|!|</b>)!)', className:'markitup-bold' },
  italic: {name:'Italic', key:'I', openWith:'(!(<em>|!|<i>)!)', closeWith:'(!(</em>|!|</i>)!)', className:'markitup-italic' },
  stroke: {name:'Stroke through', key:'S', openWith:'<del>', closeWith:'</del>', className:'markitup-stroke' },
  ul: {name:'Bulleted List', openBlockWith:'<ul>', openWith:'<li>', closeWith:'</li>', closeBlockWith:'</ul>', multiline:true, className:'markitup-list-bullet' },
  ol: {name:'Numeric List', openBlockWith:'<ol>', openWith:'<li>', closeWith:'</li>', closeBlockWith:'</ol>', multiline:true, className:'markitup-list-numeric' },
  image: {name:'Image', key:'P', replaceWith:'<img src="[![Source:!:http://]!]" alt="[![Alternative text]!]" />', className:'markitup-image' },
  link: {name:'Link', key:'L', openWith:'<a href="[![Link:!:http://]!]"(!( title="[![Title]!]")!)>', closeWith:'</a>', placeHolder:'Your text to link...', className:'markitup-link' },
  clean: {name:'Clean-up', replaceWith:function(h) { return h.selection.replace(/<(.*?)>/g, "") }, className:'markitup-clean' },
  preview: {name:'Preview', call:'preview', className:'markitup-preview' }
};