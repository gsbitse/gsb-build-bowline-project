Drupal.wysiwyg.editor.markitup.sets.markdown = {
  h1: {name:'Heading 1', key:'1', openWith:'# ', placeHolder:'Your title here...', className:'markitup-h1' },
  h2: {name:'Heading 2', key:'2', openWith:'## ', placeHolder:'Your title here...', className:'markitup-h2' },
  h3: {name:'Heading 3', key:'3', openWith:'### ', placeHolder:'Your title here...', className:'markitup-h3' },
  h4: {name:'Heading 4', key:'4', openWith:'#### ', placeHolder:'Your title here...', className:'markitup-h4' },
  h5: {name:'Heading 5', key:'5', openWith:'##### ', placeHolder:'Your title here...', className:'markitup-h5' },
  h6: {name:'Heading 6', key:'6', openWith:'###### ', placeHolder:'Your title here...', className:'markitup-h6' },
  bold: {name:'Bold', key:'B', openWith:'(!(**|!|__)!)', closeWith:'(!(**|!|__)!)', className:'markitup-bold' },
  italic: {name:'Italic', key:'I', openWith:'(!(*|!|_)!)', closeWith:'(!(*|!|_)!)', className:'markitup-italic'},
  stroke: {name:'Stroke through', key:'S', openWith:'~~', closeWith:'~~', className:'markitup-stroke' },
  ul: {name:'Bulleted List', openWith:'- ', multiline:true, className:'markitup-list-bullet' },
  ol: {name:'Numeric List', openWith: function(markItUp) {
    return markItUp.line+'. ';
  }, multiline:true, className:'markitup-list-numeric'},
  image: {name:'Image', key:'P', replaceWith:'![[![Alternative text]!]]([![Url:!:http://]!] "[![Title]!]")', className:'markitup-image' },
  link: {name:'Link', key:'L', openWith:'[', closeWith:']([![Url:!:http://]!] "[![Title]!]")', placeHolder:'Your text to link...', className:'markitup-link' },
  code: {name: 'Code block / Code', openWith:'(!(    |!|`)!)', closeWith:'(!(|!|`)!)', multiline:true, className:'markitup-code' },
  kbd: {name: 'Keyboard input', openWith:'<kbd>', closeWith:'</kbd>', className:'markitup-kbd' },
  quotes: {name: 'Quotes', openWith:'> ', className:'markitup-quotes' },
  clean: {name:'Clean-up', replaceWith:function(h) { return h.selection.replace(/<(.*?)>/g, "") }, className:'markitup-clean' },
  preview: {name:'Preview', call:'preview', className:'markitup-preview' }
};