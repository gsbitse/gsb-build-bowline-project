(function($) {

/**
 * Attach this editor to a target element.
 */
Drupal.wysiwyg.editor.attach.markitup = function(context, params, settings) {
  var markupSet = [],
      setObj = Drupal.wysiwyg.editor.markitup.sets[settings.markupSetName];

  // If there is something set in all then add it to the list of buttons.
  if (!$.isEmptyObject(Drupal.wysiwyg.editor.markitup.sets.all)) {
    for (button in Drupal.wysiwyg.editor.markitup.sets.all) {
      // First make sure this isn't already defined more explicitly. This let's
      // a plugin set a default by using all but override it for each set.
      if (typeof setObj[button] === 'undefined') {
        setObj[button] = Drupal.wysiwyg.editor.markitup.sets.all[button];
      }
    }
  }

  // Build the button layout.
  $.each(settings.buttons, function(group, buttons) {
    $.each(buttons, function(button, options) {
      var buttonValue = $.extend(setObj[button], options);
      markupSet.push(buttonValue);
    });
    markupSet.push({separator:'---------------', className:'markitup-separator' });
  });

  // Remove the last separator
  markupSet.pop();
  settings.markupSet = markupSet;

  $('#' + params.field, context).markItUp(settings);

  // Adjust CSS for editor buttons.
  $.each(settings.markupSet, function (index, button) {
    // Get button from class name, for example: markitup-h1
    var name = button.className.substr(9);
    if (name != 'separator') {
      $('.' + settings.nameSpace + ' .' + this.className + ' a')
        .css({ backgroundImage: 'url(' + settings.root + 'sets/' + settings.markupSetName + '/images/' + name + '.png' + ')' })
        .parents('li').css({ backgroundImage: 'none' });
    }
  });
};

/**
 * Detach a single or all editors.
 */
Drupal.wysiwyg.editor.detach.markitup = function (context, params, trigger) {
  if (trigger == 'serialize') {
    return;
  }
  if (typeof params != 'undefined') {
    $('#' + params.field, context).markItUpRemove();
  }
  else {
    $('.markItUpEditor', context).markItUpRemove();
  }
};

Drupal.wysiwyg.editor.instance.markitup = {
  insert: function (content) {
    $.markItUp({ replaceWith: content });
  },

  setContent: function (content) {
    $('#' + this.field).val(content);
  },

  getContent: function () {
    return $('#' + this.field).val();
  }
};

// Set default object variables so other modules can add their own sets.
Drupal.wysiwyg.editor.markitup = Drupal.wysiwyg.editor.markitup || {};
Drupal.wysiwyg.editor.markitup.sets = Drupal.wysiwyg.editor.markitup.sets || {};
Drupal.wysiwyg.editor.markitup.sets.all = Drupal.wysiwyg.editor.markitup.sets.all || {};

})(jQuery);
