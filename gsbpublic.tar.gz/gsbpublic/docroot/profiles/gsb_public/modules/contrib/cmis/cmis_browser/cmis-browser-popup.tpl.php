<?php
print $scripts;
print $styles;
print $breadcrumb;
print $children;
exit;